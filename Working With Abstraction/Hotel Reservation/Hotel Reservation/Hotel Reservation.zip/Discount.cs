﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hotel_Reservation
{
  public enum Discount
    {
        NoDiscount =0,
        VIP =20,
        SecondVisit = 10
    }
}
