﻿namespace Zoo
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Gorilla:Mammal
    {
        public Gorilla(string name)
            :base(name)
        {

        }
        
    }
}
