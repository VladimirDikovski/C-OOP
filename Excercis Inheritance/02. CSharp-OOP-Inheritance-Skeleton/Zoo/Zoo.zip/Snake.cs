﻿namespace Zoo
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Snake:Reptile
    {
        public Snake(string name)
            :base(name)
        {
            
        }
    }
}
