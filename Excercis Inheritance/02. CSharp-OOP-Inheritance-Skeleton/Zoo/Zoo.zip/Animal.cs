﻿namespace Zoo
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Animal
    {
        public string Name { get; set; }

        public Animal(string name)
        {
            this.Name = name;
        }
    }
}
