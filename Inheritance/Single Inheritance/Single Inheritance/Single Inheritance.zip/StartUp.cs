﻿namespace Farm
{
    using System;
    public class StartUp
    {
       public  static void Main(string[] args)
        {
            var dog = new Dog();
            dog.Eat();
        }
    }
}
