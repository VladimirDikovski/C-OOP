﻿namespace Farm
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating");
        }
    }
}
